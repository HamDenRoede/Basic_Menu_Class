import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {

        Scanner sc = new Scanner (System.in);
        Boolean running = true;

        while (running) {
            System.out.println("MENU");
            System.out.println("1) Say Hello");
            System.out.println("2) Quit");

            String cmd = sc.nextLine();

            if(cmd.equals("1"))
            {
                System.out.println("Hello!");
            }
            else if (cmd.equals("2"))
            {
                running = false;
            }
        }
    }
}
